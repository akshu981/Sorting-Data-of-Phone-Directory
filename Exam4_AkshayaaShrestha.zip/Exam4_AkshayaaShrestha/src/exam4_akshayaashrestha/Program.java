/*
Author: Akshayaa Shrestha
Date:12/12/2018
Description: Java application that reads tab delimited file, creates three arrays, and sorts two of those arrays.
*/
package exam4_akshayaashrestha;

import AuxPackage.AuxFileReader;
import java.util.ArrayList;


public class Program {

    
    public static void main(String[] args) 
    {
        
        //read the file and return array of strings: each row as one solid string
        String[] arRows = AuxFileReader.readFileReturnStringArray("PhoneDirectory.txt");
        
        ArrayList <ICallable> arCallable= convertToCallable( arRows);
        
        ArrayList<Employee> arEmployee = new ArrayList<Employee>();
        ArrayList<Office> arOffice= new ArrayList<Office>();
        
        splitDirectory(arCallable, arEmployee, arOffice);
        
        sortByPhone(arOffice); // sort ArrayList of Interships by required hours in descending order
          
        sortByEmployeeName(arEmployee); // sort ArrayList of regular courses by course code using selection sort
        
        displayResults(arEmployee,arOffice); // display the results
    }
    
    private static  ArrayList<ICallable> convertToCallable( String[] listValues)
    {
        
        ArrayList<ICallable> listPhoneDirect = new ArrayList<ICallable>();
        int iCount = 0;
         for (String sLine : listValues)
         {
             
             String[] arRow = sLine.split("\t"); //arRow is an array of attributes of phone directory
             
             String objectType= arRow[0];
             String personOrRoomDesc= arRow[1];
             String titleOrRooomNum= arRow[2];
             String departOrBuilding= arRow[3];
             String typeOrCapacity= arRow[4];
             int phoneExt= Integer.parseInt(arRow[5]);
             
             if(objectType.equalsIgnoreCase("E"))
             {
                 String personName= arRow[1];
                 String title= arRow[2];
                 String department= arRow[3];
                 String type= arRow[4];
                 phoneExt= Integer.parseInt(arRow[5]);
                 
                 Employee empObject= new Employee( personName, title, department, type, phoneExt );
                 
                 listPhoneDirect.add(empObject);
             }
             else
             {
                 String roomDesc= arRow[1];
                 String roomNum= arRow[2];
                 String building= arRow[3];
                 String capacity= arRow[4];
                 phoneExt= Integer.parseInt(arRow[5]);
                 
                 Office officeObject= new Office(roomDesc, roomNum, building, capacity, phoneExt);
                 listPhoneDirect.add(officeObject);
             }
         }
        return listPhoneDirect;
    }
    
    private static void splitDirectory (ArrayList<ICallable> arCallable, ArrayList<Employee> arEmployee, ArrayList<Office> arOffice)
    {
        //======================= Populate array of Employees and array of Offices  ================   
       //Iterate through the array of ICallable objects
       // casts object into either Employee or Office objects
       // assigns object to appropriate array
        
       int employeeCount = 0;   // reset employee count to use in the loop to assign next element in arEmployee
       int officeCount=0;       // reset office  count to use in the loop to assign next element in arOffice
       
       
       for(ICallable objCall: arCallable)
       {
           if(objCall.getClass().equals(Employee.class))
          {
               Employee objEmployee= (Employee)objCall; //cast ICallable to employee
               arEmployee.add(objEmployee); // assign employee objet to array element   
               employeeCount++; //increaments counter for each addition of employee object
          }
           
          else
          {
               Office objOffice = (Office)objCall; //cast ICallable to office
               arOffice.add(objOffice); // assign office objet to array element  
               officeCount++; //increaments counter for each addition of office object
               
          }

        }
       int totalCount= officeCount+employeeCount;
       System.out.println("The number of employees are: "+ officeCount);
       System.out.println("The number of offices are: "+ employeeCount);
       System.out.println("The total number of rows in Phone Directory is: "+ totalCount );
       System.out.println();

    }
    
    private static void sortByEmployeeName(ArrayList<Employee> arEmployee)
    {    
         
         String temp=null;
         //outer loop
         for(int i=0; i < arEmployee.size(); i++)// begin with 1 to have something to sort
         {
             Employee keyEmployee= arEmployee.get(i); //first unsorted item in the list
             String keyValue=keyEmployee.getPersonName();
             int minIndex=i;
             
             //inner loop
             for (int j=i+1; j<arEmployee.size(); j++){
                 
                 String thisPersonName= arEmployee.get(j).getPersonName();
                 
                 if(thisPersonName.compareTo(keyValue)<0){
                     keyValue= thisPersonName;
                     minIndex=j;
                 }
             }
             
             //perform the swap
             arEmployee.set(i, arEmployee.get(minIndex)); //move new min object to ith position
             arEmployee.set(minIndex, keyEmployee);
             
         }
    }
    
    private static void sortByPhone(ArrayList<Office> arOffice) // array of internships
    {
        for(int i=1; i < arOffice.size(); i++)// begin with 1 to have something to sort
        {
            int n= 0;
            Office keyInt= arOffice.get(i);//reference to object
            int keyPhone = keyInt.getPhoneExt();
            n=i-1; //previous
            
            while(n >= 0 && keyPhone >= arOffice.get(n).getPhoneExt())  // sort in descending order
            {
               arOffice.set(n+1,arOffice.get(n));
               n--;
            }
             arOffice.set(n+1,keyInt);
        }
    }
    
    private static void printEmployees( ArrayList<Employee>  arEmployee)
    {
      for(Employee objEmp: arEmployee){
          System.out.println(objEmp);
      }
        
    }
    
    private static void printOffices( ArrayList<Office>  arOffice)
    {
        for(Office objOffice: arOffice){
            System.out.println(objOffice);
        }
        
    }
   
        private static void displayResults(ArrayList<Employee> arEmployee, ArrayList<Office> arOffice)
    {
        System.out.println("************* List Of Employees After Sorting by their names:");
        System.out.println();
        printEmployees(arEmployee);
        System.out.println("\n\n");
        
        System.out.println("************* List Of Offices After Sorting by required phone extension:");
        printOffices(arOffice);
    }
}
