
package exam4_akshayaashrestha;


public class Employee implements ICallable {
    
    protected String personName;
    protected String title;
    protected String department;
    protected String type;
    protected int phoneExt;
    

    public Employee(String personName, String title, String department, String type, int phoneExt) {
        this.personName= personName;
        this.title=title;
        this.department=department;
        this.type=type;
        this.phoneExt= phoneExt;
    }

    public String getPersonName() {
        return personName;
    }

    public void setPersonName(String personName) {
        this.personName = personName;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public int getPhoneExt() {
        return phoneExt;
    }

    public void setPhoneExt(int phoneExt) {
        this.phoneExt = phoneExt;
    }

    
    public String call(String extension){
        extension= "You reached, " + personName + ". I am away from my desk. Leave me a message.";
        return extension;
    }
    
    public String toString()
    {
        return personName ;
    }
    
}
