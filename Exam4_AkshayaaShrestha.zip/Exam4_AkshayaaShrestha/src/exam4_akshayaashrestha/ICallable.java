
package exam4_akshayaashrestha;

public interface ICallable {
    
    public String call (String extension);
}
