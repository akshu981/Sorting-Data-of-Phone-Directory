
package exam4_akshayaashrestha;


public class Office implements ICallable {
    
    protected int phoneExt;
    protected String roomDesc;
    protected String roomNum;
    protected String building;
    protected String capacity; 
    
    public Office(String roomDesc, String roomNum, String building, String capacity, int phoneExt){
        this.roomDesc= roomDesc;
        this.roomNum= roomNum;
        this.building= building;
        this.capacity= capacity;
        this.phoneExt= phoneExt;
    }

    public String getRoomNum() {
        return roomNum;
    }

    public void setRoomNum(String roomNum) {
        this.roomNum = roomNum;
    }

    public String getBuilding() {
        return building;
    }

    public void setBuilding(String building) {
        this.building = building;
    }

    public String getCapacity() {
        return capacity;
    }

    public void setCapacity(String capacity) {
        this.capacity = capacity;
    }
    
    public int getPhoneExt() {
        return phoneExt;
    }

    public void setPhoneExt(int phoneExt) {
        this.phoneExt = phoneExt;
    }

    public String getRoomDesc() {
        return roomDesc;
    }

    public void setRoomDesc(String roomDesc) {
        this.roomDesc = roomDesc;
    }
    
    
    public String call(String extension){
        extension= "You reached the office at"+ roomDesc + "at Wesleyan College. How may I directyour call?";
        return extension;
    }
    
    @Override
    public String toString()
    {
        return roomDesc + " " + "Phone extension: " + phoneExt; 
        
    }
    
}
